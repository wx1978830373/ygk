<?php
  
  $jsonstring = file_get_contents("../xx.json");

   echo $jsonstring;
?>