var mt = 0;
window.onload = function () {
    var mydiv = document.getElementById('nav');
    var mt = mydiv.offsetTop;


    window.onscroll = function () {
        var t = document.documentElement.scrollTop || document.body.scrollTop;
        if (t > mt) {
            mydiv.style.position = "fixed";
            mydiv.style.top = "0";
            mydiv.style.backgroundColor = "#1a1f2a";
            mydiv.style.padding = "15px 0px";
        } else {
            mydiv.style.position = "static";
            mydiv.style.backgroundColor = "transparent";
            mydiv.style.padding = "0px";
        }
    }
}
$(function () {

    $(".tc").click(function () {
        $(".zuo").addClass("db");
        $('.tanchu').addClass("tanchu_w");
    });
    $(".zuo").click(function () {
        $(".tanchu").removeClass("tanchu_w");
        $(".zuo").removeClass("db");
    });

});