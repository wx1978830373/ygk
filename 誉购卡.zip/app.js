var express = require('express');

var fs = require("fs");

var app = express();

//方法1：通过express.static访问静态文件，这里访问的是ajax.html
app.use('/public', express.static("./public"));

//第一个参数表示当渲染
app.engine('html', require('express-art-template'))

//方法2：使用fs.readFile打开html文件
app.get("/", function (req, res) {
    res.render('index.html');
});
app.get("/11", function (req, res) {
    res.render('11.html');
});
app.get("/cpy", function (req, res) {
    res.render('cpy.html');
});
app.get("/lxwm", function (req, res) {
    res.render('lxwm.html');
});
app.get("/gywm", function (req, res) {
    res.render('gywm.html');
});
app.get("/zc", function (req, res) {
    res.render('zc.html');
});

app.listen(8010, function () { //监听http://127.0.0.1:3000端口
    console.log("http://127.0.0.1:8010");
});