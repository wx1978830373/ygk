

var express = require('express');

var bodyParser = require('body-parser');

var app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/fandeng";
// var collection = db.collection('tb2');

var mongoose = require("mongoose");

app.use('/public', express.static('./public'));

app.engine('html', require('express-art-template'));

var str; zlength = 0;


// 获取商品
app.get('/a', function (req, res) {
    MongoClient.connect(url, { useNewUrlParser: true }, function (err, db) {
        if (err) throw err;
        var dbo = db.db("fandeng");
        dbo.collection("data").find().toArray(function (err, result) { // 返回集合中所有数据
            if (err) throw err;
            str = result
            zlength = result.length;
            res.send(result);
            db.close();
        });
    })
})

app.get('/', function (req, res) {
    res.render('index.html');
});
app.get('/shop', function (req, res) {
    res.render('shop.html');
});

app.get('/login', function (req, res) {
    res.render('dl.html')
});
var ur = require('./user')
app.get('/pid/:id', function (req, res) {
    var id = req.params.id;
    var pushi = [];
    var pushi1 = [];
    for (var i = 0; i < zlength; i++) {

        if (id == str[i].productSeriesId) {

            var aa = str[i];
            var reg = /cover[0-9]/;
            var reg1 = /descriptionPic[0-9]/;
            var reg2 = /descriptionPic[0-9][0-9]/;

            for (var y in aa) {
                if (reg.test(y)) {
                    pushi.push(aa[y]);
                }
                if (reg1.test(y)) {

                    pushi1.push(aa[y]);

                } else if (reg2.test(y)) {
                    pushi1.push(aa[y]);
                }
            }

            res.render('xqy.html', {

                list: [aa], pushi: pushi, pushi1: pushi1
            });
            return;
        }
    }
});



app.listen(8011, function () {
    console.log("server start http://127.0.0.1:8011");
});


