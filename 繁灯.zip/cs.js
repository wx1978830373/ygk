var http=require('http');
var querystring=require('querystring');
//发送 http Post 请求
var postData=querystring.stringify({
	msg:'中文内容'
});
var options={
   hostname:'www.gongjuji.net',
   port:80,
   path:'/',
   method:'POST',
   headers:{
    'X-Hydrogen-Client-ID':"b76f488a7e3046c51504",
   	'Content-Type':'application/application/json',
   	
   }
}
var req=http.request(options, function(res) {
	console.log('Status:',res.statusCode);
	console.log('headers:',JSON.stringify(res.headers));
	res.setEncoding('utf-8');
	res.on('data',function(chun){
		console.log('body分隔线---------------------------------\r\n');
		console.info(chun);
	});
	res.on('end',function(){
		console.log('No more data in response.********');
	});
});
req.on('error',function(err){
	console.error(err);
});
req.write(postData);
req.end();
