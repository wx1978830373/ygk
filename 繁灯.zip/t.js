var MongoClient = require('mongodb').MongoClient;

var bodyParser = require('body-parser');

var express = require('express');

var jwt = require("jsonwebtoken");

var app = express();

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json())

var url = "mongodb://localhost:27017/";
app.all("*", function (req, res, next) {
    //设置允许跨域的域名，*代表允许任意域名跨域
    res.header("Access-Control-Allow-Origin", "*");
    //允许的header类型
    res.header("Access-Control-Allow-Headers", "content-type");
    //跨域允许的请求方式 
    res.header("Access-Control-Allow-Methods", "DELETE,PUT,POST,GET,OPTIONS");
    if (req.method.toLowerCase() == 'options')
        res.send(200);  //让options尝试请求快速结束
    else
        next();
})

app.get('/add', function (req, res) {
    MongoClient.connect(url, function (err, db) {
        var dbo = db.db("fandeng");
        if (err) {
            console.log(err + "连接失败");
        }
        dbo.collection("users").insertOne({
            "username": "13100632821",
            "passwrod": "123456"
        }, function (error, result) {
            if (error) {
                res.send("插入数据失败");
                return;
            }
            res.send("增加成功")
            console.log(result);
            db.close();
        })
    })
})
app.post('/all', function (req, res) {
    var zh = req.body.username;
    var mm = req.body.password
    MongoClient.connect(url, { useNewUrlParser: true }, function (err, db) {
        var dbo = db.db("fandeng");
        if (err) {
            console.log(err + "连接失败");
        }
        dbo.collection("users").find({
            "username": zh, "passwrod": mm
        }).toArray(function (error, result) {
            if (error) {
                console.log(error);
            } else if (result.length == 0) {
                res.send("登陆失败");
                console.log(result)
            }
            else {

                var content = { msg:zh}; // 要生成token的主题信息
                var secretOrPrivateKey="suiyi" // 这是加密的key（密钥） 
                let token = jwt.sign(content, secretOrPrivateKey, {
                    expiresIn: 60*60*1  // 1小时过期
                });
                console.log(result);
                res.send(token);
            }
            db.close()
        })
    })
});

app.listen(3000, function () {
    console.log("server start http://127.0.0.1:3000");
});
