var mongoose = require('./sever.js'),
    Schema = mongoose.Schema;

var UserSchema = new Schema({
    shoujihao: { type: Number },                    //用户账号
    userpwd: { type: String },                        //密码
    logindate: { type: Date }                       //最近登录时间
});

const dataSchema = new mongoose.Schema({});
const dataModel = mongoose.model('', dataSchema, 'data');
module.exports = dataModel;
