$(function () {
    var da = $(".l_b_t").children().length * 85;
    var imgnum = $('.danji').length;
    var idnex_a = 0;
    var zs = 0;
    var vvv;
    var shu = 1;
    var a;
    var zong = $(".l_b_t").children().length;
    $(".l_b_t").css({
        "width": da
    })
    //淡入淡出
    $('.bd_right button').click(function () {
        $(".tishikuang").fadeIn(1000, function () {
            $(".tishikuang").fadeOut(1000);
        })
    })


    $(".danji").children().each(function () {
        if ($(this).attr('src') == $(".lazy").attr('src')) {
            vvv = $(this).parent();
            console.log(vvv.index());
            $(this).addClass("ckc");
            return;
        }
    })
    //左点击
    $(".arrow-left").click(function () {
        if (vvv.index() == 0) {
            console.log(vvv.index());
            return;
        } else {
            var mmm = vvv.prev();
            mmm = mmm.children().addClass('ckc');
            vvv = mmm.parent();
            vvv.siblings().children().removeClass("ckc");
            a = vvv.children().attr("src");
            $(".lazy").attr("src", a);
        }
    });
    //右点击
    $(".arrow-right").click(function () {
        if (vvv.index() == imgnum - 1) {
            console.log(vvv.index());
            return;
        } else {
            var mmm = vvv.next();
            mmm = mmm.children().addClass('ckc');
            vvv = mmm.parent();
            vvv.siblings().children().removeClass("ckc");
            a = vvv.children().attr("src");
            $(".lazy").attr("src", a);
            if ($(this).position().left > 340) {
                // zs = zs + 85;
                $(".l_b_t").css({
                    "margin-left": "-" + zs + "px"
                })
            } else {
                console.log(vvv.index());

            }

        }
    })
    // 向上挪动

    $(".danji").click(function () {
        vvv = $(this);
        console.log(vvv.index());
        a = $(this).children().attr("src");
        $(".lazy").attr("src", a);
        if ($(this).children().hasClass("ckc")) {
            $(this).siblings().children().removeClass("ckc");
        } else {
            $(this).children().addClass("ckc");
            $(this).siblings().children().removeClass("ckc");
        }

        if ($(this).position().left < 85) {
            if ($(this).index() == 0 || $(this).index() == 1 || $(this).index() == 2) {
                zs = 0
                $(".l_b_t").css({
                    "margin-left": zs + "px"
                })
                return;
            }
            zs = zs - 85;
            $(".l_b_t").css({
                "margin-left": zs + "px"
            })
        };
        if ($(this).position().left > 340) {
            if ($(this).index() == zong - 1) {
                return;
            }
            zs = zs + 85;
            $(".l_b_t").css({
                "margin-left": "-" + zs + "px"
            })

        }

    });
});