$(function () {
    //更多选项点击事件
    $(".more").click(function () {
        $(this).prev().toggleClass("classify_h");
    });
    var page = 1, zongyeshu, length, localdata;

    $.ajax({
        url: '/a',
        success: function (data) {
            localdata = data;
            // console.log(localdata);
            length = localdata.length;
            laod(page);
        }
    });
    function laod(a) {
        page = a;
        $(".show").empty(); //防止重复渲染页面
        var fenyeshu = 20;
        var pagemun = fenyeshu * page;
        var html = ``;
        zongyeshu = Math.ceil(length / fenyeshu); //总页数
        if (length < pagemun) {
            // 模板渲染
            for (let i = pagemun - fenyeshu; i < length; i++) {
                html += `
                            <a href="/pid/${localdata[i].productSeriesId}">
                              <div class="show_list">
                                 <img src="${localdata[i].productPngPic}"  alt="">
                                 <p class="show_name">${localdata[i].productAliasName}</p>
                                 <p class="show_price">${localdata[i].unitPrice}元</p>
                              </div>
                            </a>`;
            }
            $('.show').append(html);
            $('.xs').html("第" + page + "页 / 总共有" + zongyeshu + "页");
            footer();
            home(page);
            xr();
            skip();
        } else {
            for (let i = pagemun - fenyeshu; i < pagemun; i++) {
                html += `
                            <a href="/pid/${localdata[i].productSeriesId}">
                              <div class="show_list">
                                 <img src="${localdata[i].productPngPic}" alt="">
                                 <p class="show_name">${localdata[i].productAliasName}</p>
                                 <p class="show_price">${localdata[i].unitPrice}元</p>
                              </div>
                            </a>`;
            }
            $('.show').append(html);
            $('.xs').html("第" + page + "页 / 共有" + zongyeshu + "页");
            footer();
            home(page);
            xr();
            skip();
        }
    }



    //加载数据后跳转
    function skip() {
        $('body,html').animate({
            scrollTop: 10
        }, 500);

    }
    $('.xiaotubiao').click(function () {
        skip();
    })
    //页头页尾效果
    function home(page) {
        if (page === 1) {
            $('.shouye').addClass("shixiao");
        } else {
            $('.shouye').removeClass("shixiao");
        }
        if (page === zongyeshu) {
            $('.weiye').addClass("shixiao");
        } else {
            $('.weiye').removeClass("shixiao");
        }
    }
    //分页渲染
    function footer() {
        $(".ip").remove();
        var str = ``;
        str += `<li><input class="ip" type="number" min="1" max="${zongyeshu}" value="${page}"></li>`;
        $('.xxx').after(str);
    }
    $(".tz").click(function () {
        laod($(".ip").val());
    })


    //分页渲染后添加事件
    function xr() {
        $(".trun").click(function () {
            var bbbb = $(this).text();
            bbbb = parseInt(bbbb);
            laod(bbbb);
        });
    }

    //分页单击事件
    $('.shouye').click(function () {
        page = 1;
        laod(page);
    });
    $('.weiye').click(function () {
        page = zongyeshu;
        laod(zongyeshu);
    });
    // 下一页
    $('[aria-label="Next"]').click(function () {
        if (page < zongyeshu) {
            page++;
            console.log(page)
            laod(page);
        } else {
            alert("最后一页了");
            page = 4;
        }
    });
    // 上一页
    $('[aria-label="Previous"]').click(function () {
        if (page > 1) {
            page--;
            console.log(page)
            laod(page);
        } else {
            alert("第一页了");
            page = 1;
        }
    });
    //加载图层
    $(document).ajaxStart(function () {
        $('.ybjz').show();
    });
    $(document).ajaxComplete(function () {
        $('.ybjz').hide();
    });
});