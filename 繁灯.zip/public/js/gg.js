$(function () {
    $('.xiaotubiao').mousedown(function () {
        $('.xiaotubiao i').css({
            'color': 'black'
        })
    });
    $('.xiaotubiao').mouseup(function () {
        $('.xiaotubiao i').css({
            'color': ''
        })
    });
    $('.xiaotubiao').mousedown(function () {
        $('.xiaotubiao i').css({
            'color': 'black'
        })
    });
    $('.xiaotubiao').mouseup(function () {
        $('.xiaotubiao i').css({
            'color': ''
        })
    });
    //滚动事件
    $(window).scroll(function () {
        var scroll_top = $(window).scrollTop();
        if (scroll_top >= 200) {
            $(".xiaotubiao").fadeIn();
        } else {
            $(".xiaotubiao").fadeOut();
        }
    })
    function skip() {
        $('body,html').animate({
            scrollTop: 10
        }, 1000);

    }
    $('.xiaotubiao').click(function () {
        skip();
    })
});


