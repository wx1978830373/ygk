var mongoose = require('mongoose');

var Schema = mongoose.Schema

mongoose.connect("mongodb://localhost/fandeng");

var userschema = new Schema({
    username: {
        type: String,
        //字段必须有值不能为空
        required: true
    },
    passwrod: {
        type: String,
        required: true
    },
    email: {
        type: String
    }
})

// var User = mongoose.model('User', userschema)

// var admin = new User({
//     username: 'zs',
//     passwrod: '123456',
//     email: 'admin@123.com'
// })
// 添加数据
// admin.save(function (err, ret) {
//     if (err) {
//         console.log('失败');
//     } else {
//         console.log('成功');
//         console.log(ret);
//     }
// })
// 查询所有数据
// User.find(function (err, ret) {
//     if (err) {
//         console.log('查询失败')
//     } else {
//         console.log(ret)
//     }
// })
// 按条件查询数据
// User.find({
// 条件语法
// username:'zs'
// },function (err, ret) {
//     if (err) {
//         console.log('查询失败')
//     } else {
//         console.log(ret)
//     }
// })
// 按条件查询单个数据
// User.findOne({username:'zs'},function (err, ret) {
//     if (err) {
//         console.log('查询失败')
//     } else {
//         console.log(ret)
//     }
// })
// 按条件删除数据
// User.remove({ username: 'zs' }, function (err, ret) {
//     if (err) {
//         console.log('删除失败')
//     } else {
//         console.log('删除成功')
//         console.log(ret)
//     }
// })
// 按条件跟新数据
// User.findByIdAndUpdate('5cc7ebc1fcaa9839e885eceb',{ passwrod: '123' }, function (err, ret) {
//     if (err) {
//         console.log('跟新失败')
//     } else {
//         console.log('跟新成功')
//         console.log(ret)
//     }
// })